import { createNavigation } from 'next-intl/navigation';
import { routing } from './routing';

// Locale-aware wrappers. Using these (instead of next/link, next/navigation)
// keeps the current locale in the URL when navigating — e.g. the language
// toggle switching /ar/services/... to /en/services/... rather than to home.
export const { Link, redirect, usePathname, useRouter, getPathname } =
  createNavigation(routing);
